INTRODUZIONE A MAXIMA - RAFFAELE VITOLO

Versione 1.0, febbraio 2007.

Una versione stampabile della guida e' il file intro_maxima.pdf.

La guida e' stata scritta con Emacs usando la libreria 'emaxima.el' e lo stile
'emaxima.sty', in una versione modificata da me per tener conto di un paio di
bachi e difetti del file originale.  La versione modificata la trovate dentro
questa cartella.  Se avete problemi con la guida, contattatemi all'indirizzo
raffaele punto vitolo chiocciola unile punto it.  Se avete problemi con Maxima,
forse e' meglio contattare persone piu' esperte di me all'indirizzo
http://maxima.sourceforge.net/

